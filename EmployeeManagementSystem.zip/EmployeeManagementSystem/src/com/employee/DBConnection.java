package com.employee;


import java.sql.Connection;
import java.sql.DriverManager;


public class DBConnection {
	

	    static String url = "jdbc:mysql://localhost:3306/jdbc_day1";
	    static String username = "root";
	    static String password = "Bhavana_838";

	    public static Connection getConnection() {

	        Connection con = null;

	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");

	            con = DriverManager.getConnection(url, username, password);

	            System.out.println("Database Connected Successfully");

	        } catch (Exception e) {

	            e.printStackTrace();
	        }

	        return con;
	    }
	}


