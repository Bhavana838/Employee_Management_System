package com.employee;

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        EmployeeDAO dao = new EmployeeDAO();

        while(true) {

            System.out.println("\n===== EMPLOYEE MANAGEMENT SYSTEM =====");

            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Delete Employee");
            System.out.println("4. Exit");

            System.out.println("Enter Choice:");

            int choice = sc.nextInt();

            switch(choice) {

            case 1:
                dao.addEmployee();
                break;

            case 2:
                dao.viewEmployees();
                break;

            case 3:
                dao.deleteEmployee1();
                break;

            case 4:
                System.out.println("Thank You");
                System.exit(0);

            default:
                System.out.println("Invalid Choice");
            }
        }
    }
}