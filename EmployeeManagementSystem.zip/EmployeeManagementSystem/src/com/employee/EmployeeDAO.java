package com.employee;

import java.sql.*;
import java.util.Scanner;

public class EmployeeDAO {

    Connection con = DBConnection.getConnection();

    // Add Employee
    public void addEmployee() {

        try {

            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Employee Name:");
            String name = sc.nextLine();

            System.out.println("Enter Salary:");
            double salary = sc.nextDouble();
            sc.nextLine();

            System.out.println("Enter Department:");
            String dept = sc.nextLine();

            String query = "INSERT INTO employee1(emp_name, emp_salary, emp_department) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setDouble(2, salary);
            ps.setString(3, dept);

            int i = ps.executeUpdate();

            if(i > 0) {
                System.out.println("Employee Added Successfully");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    // View Employees
    public void viewEmployees() {

        try {

            String query = "SELECT * FROM employee1";

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(query);

            while(rs.next()) {

                System.out.println("---------------------");

                System.out.println("ID : " + rs.getInt("emp_id"));
                System.out.println("Name : " + rs.getString("emp_name"));
                System.out.println("Salary : " + rs.getDouble("emp_salary"));
                System.out.println("Department : " + rs.getString("emp_department"));
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    // Delete Employee
    public void deleteEmployee1() {

        try {

            Scanner sc = new Scanner(System.in);

            System.out.println("Enter Employee ID:");

            int id = sc.nextInt();

            String query = "DELETE FROM employee1 WHERE emp_id=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int i = ps.executeUpdate();

            if(i > 0) {
                System.out.println("Employee Deleted Successfully");
            }
            else {
                System.out.println("Employee Not Found");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}